package org.me.gcu.ojelade_alexander_s2004585;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.me.gcu.ojelade_alexander_s2004585.R;

import java.util.LinkedList;

public class mapsFragment extends FragmentActivity implements OnMapReadyCallback{

    private GoogleMap mMap;

    private Button exit_button;

    private LinkedList <quakeClass> quakeClass;
    private LinkedList <quakeClass> list;




    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map_layout);


        SupportMapFragment mapFragment =(SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
    mapFragment.getMapAsync(this);

    Button exit_Button = findViewById(R.id.exit_button);
    exit_Button.setOnClickListener(new View.OnClickListener() {




        @Override
        public void onClick(View view){finish();}
    });
    }

    private static final double EARTH_RADIUS = 6371;

    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng glasgow = new LatLng(55.85, -4.25);

        quakeClass nearestNorth = null;
        quakeClass nearestSouth = null;
        quakeClass nearestEast = null;
        quakeClass nearestWest = null;
        quakeClass largestMagnitude = null;
        quakeClass deepest = null;
        quakeClass shallowest = null;


        LinkedList<quakeClass> quake = new LinkedList<>();



        for (quakeClass earthquake : quake) {
            double lat = earthquake.getLatitude();
            double lon = earthquake.getLongitude();

            // Calculate nearest earthquake to the north of Glasgow
            if (lat > glasgow.latitude && (nearestNorth == null || lat < nearestNorth.getLatitude())) {
                nearestNorth = earthquake;
            }

            // Calculate nearest earthquake to the south of Glasgow
            if (lat < glasgow.latitude && (nearestSouth == null || lat > nearestSouth.getLatitude())) {
                nearestSouth = earthquake;
            }

            // Calculate nearest earthquake to the west of Glasgow
            if (lon < glasgow.longitude && (nearestWest == null || lon > nearestWest.getLongitude())) {
                nearestWest = earthquake;
            }

            // Calculate nearest earthquake to the east of Glasgow
            if (lon > glasgow.longitude && (nearestEast == null || lon < nearestEast.getLongitude())) {
                nearestEast = earthquake;
            }

            // Find earthquake with largest magnitude
            if (largestMagnitude == null || earthquake.getMagnitude() > largestMagnitude.getMagnitude()) {
                largestMagnitude = earthquake;
            }

            // Find earthquake with deepest depth
            if (deepest == null || earthquake.getDepth() > deepest.getDepth()) {
                deepest = earthquake;
            }

            // Find earthquake with shallowest depth
            if (shallowest == null || earthquake.getDepth() < shallowest.getDepth()) {
                shallowest = earthquake;
            }

            // Add a marker to the map for the current earthquake
            LatLng latLng = new LatLng(lat, lon);
            mMap.addMarker(new MarkerOptions().position(latLng).title(earthquake.getLocation()));
        }

        // Zoom the map to show Glasgow and the surrounding area
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(glasgow, 6));


        // Zoom the map to show Glasgow and the surrounding area
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(glasgow, 6));

        // Show a toast message with the details of the nearest earthquakes
        String message = "Nearest North: " + nearestNorth.getLocation() + "\n" +
                "Nearest South: " + nearestSouth.getLocation() + "\n" +
                "Nearest West: " + nearestWest.getLocation() + "\n" +
                "Nearest East: " + nearestEast.getLocation() + "\n\n" +
                "Largest Magnitude: " + largestMagnitude.getLocation() + " (" + largestMagnitude.getMagnitude() + ")\n\n" +
                "Shallowest quakeClass: " + shallowest.getLocation() + " (" + shallowest.getDepth() + " km deep)";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    }